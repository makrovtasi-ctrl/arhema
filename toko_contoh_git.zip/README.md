# Toko Contoh
Website statis HTML/CSS/JS sederhana.
Dapat di-host di GitHub Pages atau Netlify.

## Struktur
- index.html : Homepage
- products.html : Daftar produk
- product.html : Detail produk
- cart.html : Keranjang
- contact.html : Kontak
- style.css : CSS responsif
- script.js : Logika keranjang
